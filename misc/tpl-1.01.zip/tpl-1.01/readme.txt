﻿Copyright (c) 2008 Akiko Kurono (crema design)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

----------------------------------------------------------------------

「iPhoneテンプレートfor MT」version1.01　導入手順

----------------------------------------------------------------------

author   > Akiko Kurono（crema design）
website  > http://cremadesign.jp/
e-mail   > cremacrema@gmail.com
created  > 2008/08/04
modified > 2008/08/05

----------------------------------------------------------------------

この配布物に関しまして何かご連絡がある場合は、下記Webページのコメント
にてお寄せください。
【「iPhoneテンプレートfor MT」を公開いたします。】
http://cremadesign.jp/blog/iphone/iphone_template_for_mt.html

----------------------------------------------------------------------

【変更履歴】

2008年8月5日
	１）内容が重複したコンテンツが存在することによる検索エンジン関連の
	　　問題を避けるために、index.mtmlとindividual.mtml両方の<head>要素内
	　　に<meta name="robots" content="noindex" />の一行を追加しました。
	　　これにより、「iPhoneテンプレートfor MT」が生成するファイルは、
	　　クロールされない設定になります。一般的にPC用のコンテンツが主で、
	　　iPhone用のコンテンツが従になると思われますので、このような設定
	　　にしました。必要ない場合は、この行を削除してください。
	
	　　【参考URL】
	　　重複コンテンツが招くSEOトラブル
	　　http://www.semilog.jp/6/20061120212701.html
	
	２）「アーカイブをサイト・パスとは別のパスで公開する」設定になっている
	　　場合、リンク切れが起こるというご報告をいただきました。そのため、
	　　該当箇所の<$MTBlogURL$>を<$MTBlogArchiveURL$>に変更しました。
	　　これにより、アーカイブを公開するURLを別途設定している場合でも
	　　していない場合でも、リンク切れを起こさないようになっていると思います。
	　　黒野の環境ではテストして動作しましたが、何かまたありましたらお知らせ
	　　ください。
	
	　　【参考URL】
	　　MTBlogArchiveURL | テンプレートタグリファレンス
	　　http://www.movabletype.jp/documentation/appendices/tags/blogarchiveurl.html
	
	３）individual.mtmlの<title>要素内に、個別のブログ記事のタイトルを
	　　出力させるために、<$MTEntryTitle$>を追加しました。
	
	４）/css/style.css内に、以下の記述を追加しました。
	　　p#logo a { text-shadow: 0px -1px 0 rgba(0, 0, 0, 0.5); }
	　　これにより、個別のブログ記事のタイトル部分に立体感が加わって、
	　　トップページと<h1>要素の体裁が揃うことになりました。
	
	５）この「iPhoneテンプレートfor MT」を公開するページを
	　　http://cremadesign.jp/blog/iphone/download.html
	　　としておりましたが、それは間違っておりましたので、
	　　http://cremadesign.jp/blog/iphone/iphone_template_for_mt.html
	　　に変更いたしました。

----------------------------------------------------------------------

【手順目次】

１）iPhone用のHTMLファイルを生成するためのディレクトリをひとつ作成する。
２）iUIライブラリをダウンロードして、１で作成したディレクトリに
　　アップロードする。
３）ダウンロードiPhoneテンプレートfor MTのファイル構成を確認する。
４）３のうち、CSSと画像ファイルを、１で作成したディレクトリに
　　アップロードする。
５）３のうち、テンプレート二つを、Movable Typeの中に設定する。
６）アーカイブマッピングを設定する。
７）再構築する。
８）iPhoneで動作確認する。

----------------------------------------------------------------------

１）iPhone用のHTMLファイルを生成するためのディレクトリをひとつ作成する。

----------------------------------------------------------------------

このテンプレートは、Movable Typeで作成された既存のブログに追加すると、
iPhoneに最適化されたHTMLファイルを別途生成するものです。

例えばあなたのブログのドメインがhttp://cremacrema.jp/で、以下のような
ディレクトリ構成になっていると仮定します。

【例】
http://cremacrema.jp/index.html
http://cremacrema.jp/category-a/index.html
http://cremacrema.jp/category-a/xxxxx.html
・
・
・
http://cremacrema.jp/category-b/index.html
http://cremacrema.jp/category-b/xxxxx.html
・
・
・
http://cremacrema.jp/category-c/index.html
http://cremacrema.jp/category-c/xxxxx.html
・
・
・

このテンプレートは、http://cremacrema.jp/i/以下に、PC用と同じ名前の
ディレクトリ構成／ファイル群を生成するように作成してあります（この
テンプレートが作成するのは、カテゴリのベースネームのディレクトリ
だけです）。

【例】
http://cremacrema.jp/i/index.html
http://cremacrema.jp/i/category-a/index.html
http://cremacrema.jp/i/category-a/xxxxx.html
・
・
・
http://cremacrema.jp/i/category-b/index.html
http://cremacrema.jp/i/category-b/xxxxx.html
・
・
・
http://cremacrema.jp/i/category-c/index.html
http://cremacrema.jp/i/category-c/xxxxx.html
・
・
・

このテンプレートに合わせ、まずはあなたのブログの公開ディレクトリ直下に
「i」という名前のディレクトリを作成してください。

【例】
ブログのドメインがhttp://cremacrema.jp/でしたら、http://cremacrema.jp/i/
を作成する。

----------------------------------------------------------------------

２）iUIライブラリをダウンロードして、1で作成したディレクトリに
アップロードする。

----------------------------------------------------------------------

<a href="http://code.google.com/p/iui/">iUIライブラリ</a>をダウンロード
してください。（リンク先のページ右カラムの「Featured Downloads」から、
iui-0.13.tar.gzをクリックします。）

ダウンロードしたファイルを解凍すると、iuiというディレクトリが入っています。

FTPクライアントを使用して、これを先ほど作成した「i」という名前のディレク
トリ直下においてください。

【例】
ブログのドメインがhttp://cremacrema.jp/でしたら、http://cremacrema.jp/i/iui/
という位置に設置できればOKです。

----------------------------------------------------------------------

３）ダウンロードiPhoneテンプレートfor MTのファイル構成を確認する。

----------------------------------------------------------------------

このreadmeをお読みになっているということは、iPhoneテンプレートfor MT
（zipファイル／xxKB）をダウンロードして解凍なさったことと思います。
解凍してできたファイル群を確認しましょう。

/tpl/readme.txt --- このファイル
/tpl/index.mtml --- トップページ生成用テンプレート
/tpl/individual.mtml --- 個別ブログ記事生成用テンプレート
/tpl/img/ --- 画像ファイル群
/tpl/css/ --- CSSファイル

----------------------------------------------------------------------

４）３のうち、CSSと画像ファイルを、１で作成したディレクトリに
アップロードする。

----------------------------------------------------------------------

さきほど解凍してできたファイル群のうち以下のものを、FTPクライアントを
使用して、先ほど作成した「i」という名前のディレクトリ直下においてください。

/tpl/img/ --- 画像ファイル群
/tpl/css/ --- CSSファイル

【例】
ブログのドメインがhttp://cremacrema.jp/でしたら、http://cremacrema.jp/i/img/
とhttp://cremacrema.jp/i/css/という位置に設置できればOKです。

----------------------------------------------------------------------

５）３のうち、テンプレート二つを、Movable Typeの中に設定する。

----------------------------------------------------------------------

/tpl/index.mtml --- トップページ生成用テンプレート
/tpl/individual.mtml --- 個別ブログ記事生成用テンプレート

上記二つのテンプレートを、下記に説明するとおりに設置していきます。


▼/tpl/index.mtml --- トップページ生成用テンプレート

	◆A:Movable Type3.3xの場合

		５－A－１）「メイン･メニュー」のブログ一覧の、作業対象ブログの
		「テンプレート」をクリックします。
		５－A－２）「インデックス・テンプレート」の一覧画面になりますので
		「テンプレートを新規作成」をクリックします。
		５－A－３）「テンプレート名」を「iPhone用トップページ」、「出力
		ファイル名」を「i/index.html」とします。
		５－A－４）「テンプレートの内容」欄に、index.mtmlの中身を丸ごと
		コピー＆ペーストして、「保存と再構築」をクリックします。（「イン
		デックス・テンプレートを再構築するときに、このテンプレートを自動
		的に再構築する」はチェックをつけておきます）
		
	◆B:Movable Type4.0x～4.1の場合

		５－B－１）ブログの管理画面で、上部の「システムメニュー→作業する
		ブログ名」を選択します。
		５－B－２）「デザイン→テンプレート」を選択します。
		５－B－３）「インデックス・テンプレート」の一覧画面になりますので
		「インデックステンプレートを作成」をクリックします。
		５－B－４）上部の細長い入力欄に「iPhone用トップページ」、次の広い
		エリアにindex.mtmlの中身を丸ごとコピー＆ペースト、「テンプレート
		の種類」は、「カスタムインデックステンプレート」、「出力ファイル
		名」を「i/index.html」とします。
		５－B－５）下部の「保存」をクリックします。（「インデックス・テン
		プレートを再構築するときに、このテンプレートを自動的に再構築する」
		はチェックをつけておきます）
		５－B－６）もう一度「保存と再構築」をクリックします。


▼/tpl/individual.mtml --- 個別ブログ記事生成用テンプレート

	◆C:Movable Type3.3xの場合

		５－C－１）「メイン･メニュー」のブログ一覧の、作業対象ブログの
		「テンプレート」をクリックします。
		５－C－２）「インデックス・テンプレート」の一覧画面になりますので
		「アーカイブ」をクリックします。
		５－C－３）「テンプレートを新規作成」をクリックします。
		５－C－４）「テンプレート名」を「iPhone用個別ページ」とし、
		「テンプレートの内容」欄に、individual.mtmlの中身を丸ごとコピー
		＆ペーストして、「保存」をクリックします。
		
	◆D:Movable Type4.0x～4.1の場合

		５－D－１）ブログの管理画面で、上部の「システムメニュー→作業する
		ブログ名」を選択します。
		５－D－２）「デザイン→テンプレート」を選択します。
		５－D－３）「インデックステンプレート」の一覧画面になりますので、
		右側の「アーカイブテンプレート」をクリックします。
		５－D－４）「アーカイブテンプレート」の一覧画面になりますので
		「アーカイブテンプレートを作成」の右側の「ブログ記事」をクリック
		します。
		５－D－５）上部の細長い入力欄に「iPhone用個別ページ」、次の広い
		エリアにindividual.mtmlの中身を丸ごとコピー＆ペーストをして、
		下部の「保存」をクリックします。

----------------------------------------------------------------------

６）アーカイブマッピングを設定する。

----------------------------------------------------------------------

個別ブログ記事用のテンプレートには、このテンプレートに合わせたアーカイブ
マッピングの設定が必要です。

▼E:Movable Type3.3xの場合

	６－E－１）「メイン･メニュー」のブログ一覧の、作業対象ブログの
	「設定」をクリックします。
	６－E－２）「公開」タブをクリックします。（「公開」タブが見当た
	らない場合には、「詳細モードに切り替え」をクリックしてください。）
	６－E－３）ページの下のほうに「アーカイブマッピング」欄があります
	ので、「マッピングを新規作成」をクリックします。
	６－E－４）「アーカイブの種類」は「エントリー」、「テンプレート」
	は「iPhone用個別ページ」を選択して「追加」をクリックします。
	６－E－５）新しく「iPhone用個別ページ」のアーカイブマッピングが
	追加されますので、プルダウンメニューから「カスタマイズする」を
	選びます。
	６－E－６）「i/%c/%f」と入力し、最下部の「変更を保存」をクリック
	します。

▼F:Movable Type4.0x～4.1の場合

	６－F－１）５－D－５）で作成した「iPhone用個別ページ」の編集画面
	を開きます。
	６－F－２）「新しいアーカイブマッピングを作成」をクリックします。
	６－F－３）「種類」を「ブログ記事」を選択して「追加」をクリックします。
	６－F－４）「パス」の下のプルダウンメニューから「カスタム」を選択
	し、「i/%c/%f」と入力します。
	６－F－５）「保存」をクリックします。

----------------------------------------------------------------------

７）再構築する。

----------------------------------------------------------------------

▼Movable Type3.3xの場合

	左側メニューの「サイトを再構築」→プルダウンメニューで「アーカイブのみ
	を再構築：エントリー」を選択して、再構築します。

▼Movable Type4.0x～4.1の場合
	管理画面上部の「再構築」ボタンをクリック→「ブログ記事アーカイブのみ」
	を選択して、再構築します。

----------------------------------------------------------------------

８）iPhoneで動作確認する。

----------------------------------------------------------------------

以上の作業にて、あなたのMovable Typeを使ったブログにiPhone用コンテンツが
追加されているはずです。iPhoneで閲覧してみましょう。

【例】
ブログのドメインがhttp://cremacrema.jp/でしたら、http://cremacrema.jp/i/を
iPhoneで閲覧する。


今後は、いつもどおりブログ記事（エントリ）を追加していけば、自動的に
iPhone用コンテンツも更新されていきます。

